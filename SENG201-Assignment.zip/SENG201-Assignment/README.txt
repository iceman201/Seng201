*******************************************************************************************************

The method of playing:

1.Click "Let pet live" fist.

2.Then every pet alives and has it own value for hungry, mood, tiredness and health.

3.Days is shows how many days passed out,start at 0.

4.When you want feet or play with pet, you have to choose which food or toy you want to feed or play.

5.There are two window behind the two combobox which for shows how many values of this item can feed
  to make pet full or play make the pet happy.

6.Be careful with Hungry value if hungry goes to 1000 or less even 0 the pet will die.

7.Health is basic on hungry and fatigue.

8.If everything you happy with the current condition of pet then click next day. After click next day
  suggest to click each pet to see them condition whether is good or not.

*******************************************************************************************************
